<?php
    
    $idade = 20;
    $nome = "Kazuhiro";

    echo "Nome " . $nome . " tem a idade " . $idade . ".<br><br>";

    $qnt_prod = 60;
    $qnt_prod = $qnt_prod - 7;
    echo "Quantidade de produto no estoque: $qnt_prod.<br><br>";

    $saldo = 5.89;
    $deposito = 2.75;
    $saldo = $saldo + $deposito;
    echo "Quantidade de dinheiro em saldo: " . number_format($saldo, 2, ",", ".") . ".<br><br>";

    $situacao = true;
    if($situacao){
        echo "<span style='color: #00ff00'>Situação positiva.</span><br><br>";
    }else{
        echo "<span style='color: #ff0000'>Situação negativa.</span><br><br>";
    }

?>