<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $a = 2;
        $b = 4;
        $c = 6;

        $soma = $a + $b + $c;
        $subtracao = $a - $b;
        $multiplicacao = $a * $c;
        $divisao = $c / $a;

        echo "<h1>Operadores Aritméticos</h1>";

        echo "A soma é: $soma.<br><br>";

        echo "A subtração entre a e b é: $subtracao.<br><br>";

        echo "A multiplicação entre a e c é: $multiplicacao.<br><br>";

        echo "A divisão entre b e a é: $divisao.<br><br>";

    ?>
    
</body>
</html>