<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $a = 1;
        $b = 2;
        $c = 3;

        if(($a == $b) AND ($b == $c)){
            echo "Utilizando AND: <span style='color: #00ff00'>Verdadeiro</span><br><br>";
        }
        else{
            echo "Utilizando AND: <span style='color: #ff0000'>Falso</span><br><br>";
        }

        if(($a != $b) OR ($a == $b)){
            echo "Utilizando OR: <span style='color: #00ff00'>Verdadeiro</span><br><br>";
        }
        else{
            echo "Utilizando OR: <span style='color: #ff0000'>Falso</span><br><br>";
        }

        if(($a > $b) XOR ($b < $c)){
            echo "Utilizando XOR: <span style='color: #00ff00'>Verdadeiro</span><br><br>";
        }
        else{
            echo "Utilizando XOR: <span style='color: #ff0000'>Falso</span><br><br>";
        }

        if(($a == $b) && ($b == $c)){
            echo "Utilizando AND: <span style='color: #00ff00'>Verdadeiro</span><br><br>";
        }
        else{
            echo "Utilizando AND: <span style='color: #ff0000'>Falso</span><br><br>";
        }

        if(($a != $b) || ($a == $b)){
            echo "Utilizando OR: <span style='color: #00ff00'>Verdadeiro</span><br><br>";
        }
        else{
            echo "Utilizando OR: <span style='color: #ff0000'>Falso</span><br><br>";
        }
    ?>
</body>
</html>