<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $a = 8;
        $b = 10;

        if($a == $b){
            echo "Os valores de a e b são iguais<br><br>";
        }
        else{
            echo "Os valores de a e b são diferentes<br><br>";
        }

        if($a >= $b){
            echo "O valor de a é maior que o de b<br><br>";
        }
        else{
            echo "O valor de b é maior que o de a<br><br>";
        }

        if($a <= $b){
            echo "O valor de a é menor que o de b<br><br>";
        }
        else{
            echo "O valor de b é menor que o de a<br><br>";
        }

        if($a != $b){
            echo "O valor de a é diferente que o de b<br><br>";
        }
        else{
            echo "O valor de a é igual ao de b<br><br>";
        }

        while($a <= $b){
            echo "O valor de a é menor que o valor de b<br><br>";
            $a ++;
            echo "Agora o valor de a é: $a<br><br>";
        }
        
    ?>
</body>
</html>