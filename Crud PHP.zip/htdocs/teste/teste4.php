<?php

    $a = 5;
    $b = 2;
    $c = 10;
    $result = 0;

    $result += $a;
    echo "A soma resultou em: $result.<br><br>";

    $result -= $b;
    echo "A subtração resultou em: $result.<br><br>";

    $result *= $c;
    echo "A multiplicação resultou em: $result.<br><br>";

    $result /= $b;
    echo "A divisão resultou em: $result.<br><br>";

    $result %= $a;
    echo "O resultado do módulo é: $result.<br><br>";

    $d = "Oi, ";
    $d .= "Tudo ";
    $d .= "Bem?";

?>